from zbiosens.core import CapteursBiologiquesZoran

capteur = CapteursBiologiquesZoran()
capteur.collecter(1.0)
capteur.collecter(3.0)
print("Moyenne:", capteur.traiter())
