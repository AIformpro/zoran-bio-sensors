import numpy as np

class CapteursBiologiquesZoran:
    def __init__(self):
        self.signaux = []
    def collecter(self, signal):
        self.signaux.append(signal)
        return "Signal collecté"
    def traiter(self):
        return np.mean(self.signaux) if self.signaux else None
