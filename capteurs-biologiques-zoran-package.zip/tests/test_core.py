from zbiosens.core import CapteursBiologiquesZoran

def test_collecter_traiter():
    capteur = CapteursBiologiquesZoran()
    capteur.collecter(1.0)
    capteur.collecter(3.0)
    assert capteur.traiter() == 2.0
